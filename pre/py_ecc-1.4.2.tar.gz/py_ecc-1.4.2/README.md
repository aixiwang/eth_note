Implements optimal ate pairings over the bn\_128 curve.
